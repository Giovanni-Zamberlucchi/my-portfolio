# DC Maintenance mode for Netlify

Most simple maintenance mode HTML for Netlify.

## Usage

- Donwload zip file
- Upload the zip file to Netlify
- Publish the deploy

## Special Thanks
- Base HTML file: https://gist.github.com/pitch-gist/2999707